
public class kioskMain {

    public static void main(String[] args) {
        Kiosk kiosk = new Kiosk();
        kiosk.menuChoice();

    }

}

